package grade;
import java.io.File;
/**
 * @author Iverson
 *
 */
public class Grade {
	public static void main(String args[]) {
		// 爬取教务网页上的成绩
		String urlhtml = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Mon%20Sep%2021%202015%2010:41:24%20GMT+0800%20(CST)";
		String htmlPath = "Grade.html";
		//爬取教务网页上的一个js
		String urljs="http://upcdn.b0.upaiyun.com/libs/jquery/jquery-2.0.3.min.js";
	    String jsPath="Grade.js";
	    //爬取教务网页上的一个css
	    String urlcss="http://testjoking.sinaapp.com/whujw/extension/bootstrap.css";
	    String cssPath="Grade.css";
        //写入成绩
		HttpRequest requesthtml = HttpRequest.get(urlhtml);
		requesthtml.header("Cookie",
				"JSESSIONID=23D2B7D6DC7531E955AEB4DB2C12065D.tomcat2");
		requesthtml.receive(new File(htmlPath));
		//写入js
		HttpRequest requestjs = HttpRequest.get(urljs);
		requestjs.receive(new File(jsPath));
		//写入css
		HttpRequest requestcss = HttpRequest.get(urlcss);
		requestcss.receive(new File(cssPath));
	}
}

