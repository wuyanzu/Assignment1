package assignment1;

import java.io.File;

public class CZy {
		public static void main(String[] arg){
			String url="http://210.42.121.133/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Sun%20Sep%2020%202015%2021:50:28%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";//�ɼ�����ַ
			HttpRequest report= HttpRequest.get(url);
			report.header("Cookie","JSESSIONID=8BED82D599658FADAF2CD26AD90FEEBF.tomcat2");//��ȡ�ɼ�
			String myReport="myReport.html";
			if(report.ok()){
			report.receive(new File(myReport));//д���ҵ��ļ�
		}
		}
}




